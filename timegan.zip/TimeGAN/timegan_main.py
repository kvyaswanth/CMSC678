## Necessary packages
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import warnings
warnings.filterwarnings("ignore")

# 1. TimeGAN model
from timegan import timegan
# 2. Data loading
from data_loading import real_data_loading, sine_data_generation
# 3. Metrics
from metrics.discriminative_metrics import discriminative_score_metrics
from metrics.predictive_metrics import predictive_score_metrics
from metrics.visualization_metrics import visualization

def lrnz_data_gen(no, seq_len=10000):
  """
  Args:
    - no: the number of samples
    - seq_len: sequence length of the time-series
    - dim: feature dimensions

  Returns:
    - data: generated data
  """
  # Initialize the output
  data = list()

  def lorenz(x, y, z, s=10, r=28, b=2.667):
    x_dot = s*(y - x)
    y_dot = r*x - y - x*z
    z_dot = x*y - b*z
    return x_dot, y_dot, z_dot

  # Generate sine data
  for i in range(no):
    # intial condition
    x = np.empty((seq_len,3))
    init = np.random.uniform(0.0, high=10, size=(1,3))[0]
    x[0] = init

    for i in range(seq_len-1):
      x_dot, y_dot, z_dot = lorenz(x[i][0], x[i][1], x[i][2])
      x[i+1][0] = x[i][0] + (x_dot * 0.01)
      x[i+1][1] = x[i][1] + (y_dot * 0.01)
      x[i+1][2] = x[i][2] + (z_dot * 0.01)

    data.append(x)

  return data

fpath = '/home/v117/manas_user/tsgan_data/'

#for i in range(10_000):
#  print(i)
#  odata = lrnz_data_gen(1)
#  odata = np.array(odata)
#  np.savetxt(f'{fpath}lrnz_{i}.txt', odata.reshape(1,-1))



ori_data = []

for i in range(10_000):
#  print(i)
  odata = np.loadtxt(f'{fpath}lrnz_{i}.txt')
  odata = odata.reshape(10000,3)
  ori_data.append(odata)

print(len(ori_data))
print(np.array(ori_data).shape)




## Newtork parameters
parameters = dict()

parameters['module'] = 'gru' 
parameters['hidden_dim'] = 24
parameters['num_layer'] = 3
parameters['iterations'] = 10#000
parameters['batch_size'] = 128



# Run TimeGAN
generated_data = timegan(ori_data, parameters)   
print('Finish Synthetic Data Generation')

metric_iteration = 5

discriminative_score = list()
for _ in range(metric_iteration):
  temp_disc = discriminative_score_metrics(ori_data, generated_data)
  discriminative_score.append(temp_disc)

print('Discriminative score: ' + str(np.round(np.mean(discriminative_score), 4)))



predictive_score = list()
for tt in range(metric_iteration):
  temp_pred = predictive_score_metrics(ori_data, generated_data)
  predictive_score.append(temp_pred)   
    
print('Predictive score: ' + str(np.round(np.mean(predictive_score), 4)))


